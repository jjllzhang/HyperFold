#!/usr/bin/env bash
set -uo pipefail
trap 'result=$?; printf "%s\n" "$result" > /home/zjl/zkp-research/experiments/hyperfold-bench/mu30-recovered-formal-2026-11-06/exit-status; date -u --iso-8601=seconds > /home/zjl/zkp-research/experiments/hyperfold-bench/mu30-recovered-formal-2026-11-06/finished-utc.txt' EXIT
cd /home/zjl/HyperFold
flock -n /home/zjl/zkp-research/experiments/hyperfold-bench/mu30-recovered-formal-2026-11-06/runner.lock python3 scripts/attempt_query_extremes.py --binary target/release/bench --root /home/zjl/zkp-research/experiments/hyperfold-bench/mu30-recovered-formal-2026-11-06/data
