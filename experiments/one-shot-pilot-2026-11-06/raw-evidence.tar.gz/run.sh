#!/usr/bin/env bash
set -uo pipefail
trap 'result=$?; printf "%s\n" "$result" > /home/zjl/zkp-research/experiments/hyperfold-bench/one-shot-pilot-2026-11-06/exit-status; date -u --iso-8601=seconds > /home/zjl/zkp-research/experiments/hyperfold-bench/one-shot-pilot-2026-11-06/finished-utc.txt' EXIT
cd /home/zjl/HyperFold
flock -n /home/zjl/zkp-research/experiments/hyperfold-bench/one-shot-pilot-2026-11-06/runner.lock python3 scripts/run_one_shot_lifetimes.py --binary target/release/examples/one_shot_lifetimes --root /home/zjl/zkp-research/experiments/hyperfold-bench/one-shot-pilot-2026-11-06/data --mu 26 --rounds 2
