#!/usr/bin/env bash
set -uo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/exit-status; date -u --iso-8601=seconds > /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/finished-utc.txt' EXIT
cd /home/zjl/HyperFold
export RUSTFLAGS='-C target-cpu=native'
flock -n /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/runner.lock python3 scripts/run_sweep.py --binary target/release/bench --output-dir /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06 --memory-mode retained --allow-memory-skips --max-estimated-gib 480 --min-available-gib 12 --repetitions 3 --reuse-completed-from /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r2-2026-11-05
