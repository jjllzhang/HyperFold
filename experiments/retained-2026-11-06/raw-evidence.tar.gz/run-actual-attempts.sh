#!/usr/bin/env bash
set -uo pipefail
trap 'rc=$?; printf "%s\n" "$rc" > /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/actual-attempt-exit-status; date -u --iso-8601=seconds > /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/actual-attempt-finished-utc.txt' EXIT
cd /home/zjl/HyperFold
flock -n /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06/actual-attempt.lock python3 scripts/attempt_retained_extremes.py --root /home/zjl/zkp-research/experiments/hyperfold-bench/v3-r3-no-recompute-2026-11-06 --estimate-bypass-gib 1024
