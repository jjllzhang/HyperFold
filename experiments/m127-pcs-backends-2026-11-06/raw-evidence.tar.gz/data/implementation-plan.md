# M127三后端完整PCS代表点对照：适配规范 v1

Architect，2026-11-06；Jal1n `ae4b0be0`，ProverDev `6d0c4198`，task #19。

## 0. 本轮最新范围与立即可执行部分

本轮先比较**冻结的当前自研、ark-ff、FourQ原生C接入同一完整PCS后的实际性能**，仅四个代表点：μ∈{20,26}、r=2、c=4、QA/RS。均M127 e2、32线程、最新one-shot内存策略。暂不启动72组重跑，自研算术优化排在后端比较之后；旧路径清理仍是后续独立提交，不与此次适配混改。

此范围取代上一规范中“先优化再全72组”的当前执行顺序，不构成永久禁止未来全量实验。旧实验与完整微基准都已结束，不需等待旧负载。ProverDev可立即实施ark适配、三方接口与测试/runner；FourQ原生冗余表示必须按Theorist已确认的闭合范围接通，不能为了赶进度默认任意未证范围成立。

这里的“直接替换”是实验后端的接口替换，不是改一个类型别名，也不是已决定替换生产默认实现。测试与计时通过后才比较优劣。

## 1. 模块边界：不改协议和共享Plonky3

建议新独立benchmark-only包`benchmarks/m127-pcs-compare/`，模块：
- `ark_field`：本地newtype包装ark-ff0.6.0同p的Fp128/MontBackend，P3 trait适配。
- `fourq_field`＋薄C桥：固定FourQ1031567f… x64 C/noASM，用已有相同源及MIT notice。
- driver：静态泛型实例化`HyperFoldPcs<F,E>`三种后端，复用OpeningOnlyPcs、OwnedWitness、CommittedOracle和全部协议代码；只在CLI分派一次，不在元素热循环用dyn trait。
- correctness：跨域后端差分、canonical字节、跨backend proof验证。
- scheduler/report：单版本固定binary、顺序进程、轮换backend顺序、原始记录与归档。

生产`field_m127.rs`保持冻结，root Cargo不默认增加ark/C依赖，旧微基准包及其固定binary/源码证据不被“顺手优化”。不改共享Plonky3 vendor，不引入另一套Merkle、Transcript、参数表或Sumcheck算法。确实需要抽取公共harness时只移动通用生命周期代码，回归后单独说明。

## 2. 必须相同的数学身份和外部表示

所有后端p=2^127−1，E=F[X]/(X²+1)，系数序a+bi；基域generator43、扩域generator8+i，其他P3常量与现实现一致。

- `SampleBase::KIND=M127`；复用现有拒绝采样规则：每次读16B、mask127bits、拒绝p，不改为各库自带PRNG或mod reduction。必须消耗相同XOF字节数，Setup与挑战完全相同。
- `SampleBase::fft_root`保持当前M127行为；不要凭ark的FftField trait另换RS构造。
- `BinomiallyExtendable::binomial_algebra_id`保持`hyperfold-m127-power-basis-v1:X^2+1`；参数ID绑定同一数学对象，不塞入后端名。后端名写实验metadata，不改协议输入。
- base规范编码恰好16B little-endian，E为原有两系数顺序32B。Serialize/Deserialize、RawDataSerializable::into_bytes及所有用于流式哈希的接口都必须输出同一canonical字节。
- Deserialize仍拒绝≥p，不把非法外部编码默默规约；不要直接derive ark内部/Montgomery limbs或FourQ原生limbs的serde。
- 所有Eq/Ord/Hash/is_zero/is_one/Display/PrimeField canonical导出必须表达数学值；尤其FourQ原生p与0相等且Hash相同。try_inverse对0和冗余p都返回None，不能调用C后返回Some(0)。
- Base对象16B、二次扩域32B，Packing仍为标量Self。记录实际size/alignment；不得用额外缓存对象/堆指针把每元素存储变大，或为比较而保留整份canonical副本。

`mmcs::LeafHash`实际调用NUM_BYTES/into_bytes；Transcript::observe实际用postcard Serialize。这两条路径分别验证，不能只测serde就假定Merkle根一致。

## 3. ark适配

Rust orphan规则要求本地newtype，不可直接给外部ark类型实现外部P3 trait。实现Field/PrimeCharacteristicRing/PrimeField、RawDataSerializable、QuotientMap、迭代算术/赋值运算、Packable、Serde和SampleBase等当前PCS所需接口；参考现有field_m127.rs的边界语义。

内部始终持有Montgomery值，add/sub/mul/square/inverse调用ark接口。只在canonical编码、哈希和比较所需边界导出普通值，不在每次乘法后往返转换。输入转换实际发生在Setup/输入阶段，流式Merkle导出实际发生在commit/open阶段，这些成本都保留在该阶段计时。

本轮正式ark/FourQ后端采用**显式[Base;2]存储的E newtype**（与ProverDev消息3ad4991b对齐），实现BasedVectorSpace时直接借用自己的两个系数，不将ark Fp2等外部结构未经保证地reinterpret成切片。运算时由两个已有内部Montgomery系数构造临时ark Fp2、调用原生运算、取回c0/c1；这些是常数大小移动，不做canonical往返转换或大表clone。E mul/square/inverse及mixed均映射实际原生运算；保持Algebra<F>、AlgebraIdentity及32B编码兼容。

原因：P3 BinomialExtensionField可通过ExtensionAlgebra覆盖ext_mul/ext_square/ext_base_mul，但其D=2 try_inverse仍固定调用P3 quadratic_inv，没有公开ext_inverse hook。因此该组合仅可作功能性参考或另标“P3扩域＋外部基域”对照，不充当本轮完整原生二次扩域正式后端。不要修改vendor添加hook，也不要把仍用通用3乘平方的版本声称为测试了ark专用平方。

## 4. FourQ原生表示与调用边界

原生backend的意思是：运行已固定的上游C算术，而非把我们的算术改写成看似FourQ风格的Rust后再称第三方。可使用本地newtype＋薄C桥，F与E热点尽量调用对应原生例程。

### 表示正确性

Theorist已于消息4b4e2f56确认固定Linux/AMD64、UINT128 C/noASM的base/extension操作对[0,p]冗余表示的闭合条件；可在此合同下长期保留原生表示，仅在Eq/Hash/zero判定/canonical编码等必要边界规约。该范围不是任意u128约简保证，不外推至其他FourQ分支。必须逐操作确认add/sub/neg/mul/square/inverse/halve及Fp2组合，不把“乘法闭合”外推到所有操作。

若个别操作需额外规约，在该操作适配层显式执行并报告；不自动给每个原生运算都加mod1271，再把冗余包装当作最优原生结果。数学条件未确认时可以先完成接口和canonical保守测试路径，但不能将该保守路径冒称已测原生闭合后端。

### C桥与性能解释

- 明确u64 limb数组、size/alignment、输出与输入是否允许别名，unsafe仅限小范围桥接；不把ark对象或未声明布局的Rust u128数组直接cast给C。
- 单元素/扩域P3调用可以经过专用薄FFI函数。**不能复用微基准的op/维度/contract运行时多分派fq_batch(n=1)来当作最薄原生桥**；编译时固定域宽/具体运算，避免额外dispatch与不必要copy。
- 相比之前微基准，真实PCS的泛型标量调用可能频繁跨FFI，这就是此接入方式的实际成本；不从计时中扣除，也不根据批量微基准假设该成本不存在。
- E采用上述显式[Base;2]包装，乘法/平方/逆元委托对应Fp2原生例程，不人为拆成多次基域FFI；系数借用直接指向自有数组。源码复核已确认有fp2add/sub/neg及fpdiv/fp2div，本轮按ProverDev eb4ee46c直接薄桥调用，减少可避免的重复标量FFI。mixed可在一次C桥内组合两个原生base乘法并在操作映射表明确，不能偷偷混用自研热路径。
- 首轮不加入cross-language LTO、全PCS批量融合或手写ASM来“修饰”比较；若薄FFI后端落后，可随后单独讨论融合/本地移植，不将一次适配结果泛化成FourQ数学算法不行。

## 5. 正确性验收先于计时

1. 三后端base/E随机与边界差分、加减乘平方逆元、mixed、Frobenius与生成元；FourQ额外覆盖0和p的各操作组合、Eq/Hash/Ord、非规范输出，验证闭合与规范导出。
2. 原有各类PCS正确性/篡改检查保持，1线程仅功能性检查，32线程检查结果一致。小规模覆盖QA/RS、r2/4/8、c2/4、深度1–4，以防只为代表点硬编码。
3. 固定seed逐值核对Setup正逆表、原始消息/点、commit root、y0、全部Proof规范字节、P/V后续挑战。所有backend的parameters_id相同。
4. 小规模跨backend验证：A后端生成的commit/proof规范字节，由B后端反序列化并验证（3×3），含被篡改/非canonical外部编码拒绝。
5. one-shot不变：forward在最后commit后真正drop，witness首子轮fold完成后drop；inverse/base/top-oracle保留到真实最后使用点；调用者Oracle在verify/序列化后清理，无整表canonical clone。容量/释放时点与旧成功harness标记相同。
6. 两种build/default+native通过check/test/Clippy，四类测试可复查。新C桥最好有针对别名、长短buffer/边界的测试；接口应通过Rust类型/长度检查排除非法调用。

## 6. 四代表点与计时方案

固定M127 e2、μ20/26、r2c4、QA/RS，共4参数点。每个点三个backend：ours_frozen、ark_adapter、fourq_native_adapter。初轮建议三次独立进程轮次，backend顺序ABC/BCA/CAB，共36进程；每进程1预热+3正式trial，共108正式记录。若运行成本需缩减，先明示减少独立轮次，不能把进程内重复当独立轮次。

仅32线程实际计时，所有backend相同release/native和线程/进程亲和策略。原微基准若采用32物理core亲和，PCS三方也统一使用同一策略并记录；不称独占核心，不与其他负载并行跑。

每trial完全相同外层流程：fresh Setup→输入及y准备→commit→forward-release→open_once→verify→序列化→cleanup。全部同种子。直接按相同拒绝采样规则生成目标backend对象，避免额外保留一份大canonical输入表。

记录Setup、input、commit、forward_release、open（含witness释放及查询行恢复）、verify、serialization、diagnostics、cleanup、wall；online_total=commit+forward_release+open+verify。临时表示转换若发生在这些函数中，计入对应函数，不扣除“适配开销”。证明大小与字段原样，进程RSS统计Setup+预热+所有trial，而非仅open。

比较至少分别给出：commit、open、verify、online_total、full wall、peak RSS、proof bytes；不能以最好的单一算术kernel选总赢家。按三进程均值与配对轮次差值/SD/范围解释；选择Backend时同时考虑生产依赖、维护、unsafe、表示复杂度与性能，不只看一个percent。

## 7. 冻结/归档/验收标准

- 固定三后端同一binary和依赖版本，manifest含各backend操作映射（尤其E inverse）、内存布局、编码契约、source/lock/C版本与flags、CPU亲和、线程、种子、协议参数、生命周期、重复数和查询策略。
- 新空目录、不可变execution-contract、每行backend标签，失败真实留档且不形成完整均值，不自动回退自研或规范化模式。
- 原始proof/Transcript指纹、大小、参数、释放标记、退出/RSS均核验，统计表能从纯归档重建。适配改变时重开版本/数据集，不混跑。
- 当前不启动全72组；完成四点三方实测后向Jal1n报告最合适路径，未经比较不能直接把某个实验后端设为生产默认。此前自研优化/清理计划仍可作为后续候选，但不阻塞本轮。

本规范是工程适配与公平比较约束，不是Finite Field实现安全证明。Theorist负责FourQ闭合范围的数学核对，Architect后续只读复核代码及证据。
