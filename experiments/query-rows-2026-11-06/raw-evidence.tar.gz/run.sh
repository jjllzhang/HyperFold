#!/usr/bin/env bash
set -uo pipefail
trap 'result=$?; printf "%s\n" "$result" > /home/zjl/zkp-research/experiments/hyperfold-bench/query-rows-overhead-2026-11-06/exit-status; date -u --iso-8601=seconds > /home/zjl/zkp-research/experiments/hyperfold-bench/query-rows-overhead-2026-11-06/finished-utc.txt' EXIT
cd /home/zjl/HyperFold
flock -n /home/zjl/zkp-research/experiments/hyperfold-bench/query-rows-overhead-2026-11-06/runner.lock python3 scripts/profile_query_rows.py --binary target/release/examples/query_row_overhead --output-dir /home/zjl/zkp-research/experiments/hyperfold-bench/query-rows-overhead-2026-11-06/data
